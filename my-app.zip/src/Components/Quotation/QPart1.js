import React from "react";

function QPart1() {
  return (
    <div>
      <h2>Select Service</h2>
    </div>
  );
}

export default QPart1;
